﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodReadTesting
{
    public static class Privates
    {
        public const string LoginEmail = "daniterminatora@gmail.com";
        public const string LoginPassword = "3v1L@4v5C8L";
    }
}
